export class deputado{
    nome: string = ''
    siglaPartido: string = ''
    siglaUf: string = ''
    urlFoto: string = ''
    email: string = ''
}