import { deputado } from "./deputado";

export class Resposta{
    dados: deputado[] = []
}