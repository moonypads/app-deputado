import { Component } from '@angular/core';
import { deputado } from '../deputado';
import { DeputadoService } from '../deputado.service';

@Component({
  selector: 'app-busca-deputado',
  templateUrl: './busca-deputado.component.html',
  styleUrls: ['./busca-deputado.component.css']
})
export class BuscaDeputadoComponent {
  deputados: deputado[]
  constructor(private ds: DeputadoService){
  this.deputados = []
  }
  
  buscar(nome: string){
    this.ds.obterDeputadoPorNome(nome).subscribe(res =>{
      this.deputados = res.dados

    })
  }
}
